package bean



//消息队列中的一条记录
type Message struct {
	Topic     string
	//Data 对应数据库中的一条记录
	Data      Data
}


//Data 对应数据库中的一条记录
type Data struct {
	Id    string
	Info  string
}



