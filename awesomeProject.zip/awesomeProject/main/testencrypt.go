package main

import (
	"awesomeProject/main/encrypt"
	"fmt"
)

func main() {
	//key := []byte("examplew")
	//encrypt.Encrypt("adadadadadad",key)
	src := []byte("iamwedwadwadawdawdawdk")
	key := []byte("12345678")

	crypt := fmt.Sprintf("%x", encrypt.DesEncrypt(src, key))
	fmt.Print(crypt)
	fmt.Println()

	fmt.Printf("%s", encrypt.DesDecrypt(encrypt.DesEncrypt(src, key), key))
	fmt.Println()

}