package producer

import (
	"awesomeProject/main/bean"
	"encoding/json"
	"github.com/Shopify/sarama"
	"log"
	"sync"
	"sync/atomic"
)

func AsyncProduver(kafkaIp []string,topic string ,mess []bean.Message) {
	//构造kafka配置  并连接kafka
	config:=sarama.NewConfig()
	//等待服务器所有副本都保存成功后的响应
	config.Producer.RequiredAcks = sarama.WaitForAll
	//随机的分区类型
	config.Producer.Partitioner = sarama.NewRandomPartitioner
	config.Producer.Return.Successes=true
	producer,err:=sarama.NewAsyncProducer(kafkaIp,config)
	if err !=nil{
		log.Fatal("NewAsyncProducer err:",err)
	}
	defer producer.Close()
	//read from channel
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		for {
			select {
			case s :=<-producer.Successes():
				if(s!=nil){
					log.Printf("[Producer] key:%v msg:%+v \n", s.Key, s.Value)
				}else{
					log.Printf("%v",s)
				}
			case e := <-producer.Errors():
				if e != nil {
					log.Printf("[Producer] err:%v msg:%+v \n", e.Msg, e.Err)
				}
			}
		}
	}()

	limit:=len(mess)
	//async send
	for i := 0; i < limit; i++ {
		//构造消息体
		//str := strconv.Itoa(int(time.Now().UnixNano()))
		s,_:=json.Marshal(mess[i]);
		str := string(s)
		msg := &sarama.ProducerMessage{Topic: topic, Key:nil,Value: sarama.StringEncoder(str)}

		// 异步发送只是写入内存了就返回了，并没有真正发送出去
		// sarama 库中用的是一个 channel 来接收，后台 goroutine 异步从该 channel 中取出消息并真正发送
		producer.Input() <- msg

		var count int64
		atomic.AddInt64(&count,1)
		if atomic.LoadInt64(&count)%1000 == 0 {
			log.Printf("已发送消息数:%v\n", count)
		}





	}
	log.Printf("发送完毕 总发送消息数:%v\n", limit)
	//wg.Wait()

}


