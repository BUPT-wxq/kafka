package main

import (
	"awesomeProject/main/bean"
	"awesomeProject/main/producer"
	"strconv"
	"time"
)




func main()  {
	//构造消息
	var mess []bean.Message
	//构造十条数据库记录
	for j:=0;j<10;j++{
		m:=bean.Message{};
		m.Topic="web_log"
		m.Data.Id=string(j)
		m.Data.Info=strconv.Itoa(int(time.Now().UnixNano()))
		mess=append(mess,m)
	}

	//producer.SyncProducer([]string{"123.56.14.174:9092","123.56.14.174:9093","123.56.14.174:9094"},"test1",10)
	producer.AsyncProduver([]string{"123.56.14.174:9092","123.56.14.174:9093","123.56.14.174:9094"},"test3",mess)
}
