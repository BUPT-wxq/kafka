package consumer

import (
	"awesomeProject/main/bean"
	"awesomeProject/main/encrypt"
	"awesomeProject/main/ethereum"
	"encoding/json"
	"fmt"
	"github.com/Shopify/sarama"
	"log"
	"sync"
	"time"
)

//实现多分区消费者  提交offset
//func PatitionsConsumer(kafkaIp []string,topic string) {
//	config:=sarama.NewConfig();
//	consumer,err:=sarama.NewConsumer(kafkaIp,config)
//	if err!=nil{
//		log.Fatal("NewClient err:",err)
//	}
//	defer consumer.Close()
//	partitions,err:=consumer.Partitions(topic);
//	if err!=nil{
//		log.Fatal("NewClient err:",err)
//	}
//
//	var wg sync.WaitGroup
//	for _,partitionId := range partitions {
//		fmt.Println(partitionId)
//		//为每一个分区开一个分区消费者
//		//consumeByPartition(topic,consumer, int32(partitionId), &wg)
//		defer wg.Done()
//		partitionConsumer, err := consumer.ConsumePartition(topic, partitionId, sarama.OffsetOldest)
//		if err != nil {
//			log.Fatal("ConsumePartition err: ", err)
//		}
//		defer partitionConsumer.Close()
//		wg.Add(1)
//		go func(sarama.PartitionConsumer) {
//			for msg:=range partitionConsumer.Messages(){
//				fmt.Printf("Partition:%d, Offset:%d, key:%s, value:%s\n", msg.Partition, msg.Offset, string(msg.Key), string(msg.Value))
//			}
//			defer partitionConsumer.AsyncClose()
//
//		}(partitionConsumer)
//
//	}
//	wg.Wait()
//
//}
func PartitionsConsumer(kafkaIp []string,topic string){
	config := sarama.NewConfig()
	// 配置开启自动提交 offset，这样 samara 库会定时帮我们把最新的 offset 信息提交给 kafka
	//config.Consumer.Offsets.Initial=sarama.OffsetOldest
	config.Consumer.Offsets.AutoCommit.Enable = true              // 开启自动 commit offset
	config.Consumer.Offsets.AutoCommit.Interval = 1 * time.Second // 自动 commit时间间隔
	client, err := sarama.NewClient(kafkaIp, config)
	if err != nil {
		log.Fatal("NewClient err: ", err)
	}
	defer client.Close()
	// offsetManager 用于管理每个 consumerGroup的 offset
	// 根据 groupID 来区分不同的 consumer，注意: 每次提交的 offset 信息也是和 groupID 关联的
	offsetManager, err:= sarama.NewOffsetManagerFromClient("myGroupID-1", client) // 偏移量管理器
	if err != nil {
		log.Fatal("NewOffsetManagerFromClient err: ", err)
	}
	defer offsetManager.Close()

	partitionIds,_:=client.Partitions(topic)
	var wg sync.WaitGroup
	//根据客户端创建一个消费者
	consumer, _ := sarama.NewConsumerFromClient(client)
	c:=make(chan []byte,100)
	for _,partitionId :=range partitionIds{
		fmt.Println("PartitionID:",partitionId,"topic",topic)
		// 每个分区的 offset 也是分别管理的
		partitionOffsetManager, err := offsetManager.ManagePartition(topic, int32(partitionId)) // 对应分区的偏移量管理器
		if err != nil {
			log.Fatal("ManagePartition err: ", err)
		}
		defer partitionOffsetManager.Close()
		nextOffset, _ := partitionOffsetManager.NextOffset() // 取得下一消息的偏移量作为本次消费的起点
		fmt.Println("PartitionID:",partitionId,"offset:",nextOffset)
		partitionConsumer, err := consumer.ConsumePartition(topic, partitionId, nextOffset)
		if err != nil {
			log.Fatal("ConsumePartition err: ", err)
		}
		defer partitionConsumer.Close()
		wg.Add(1)
		//为每一个消费者分区开一个协程
		go func(sarama.PartitionConsumer) {
			defer wg.Done()
			for msg:=range partitionConsumer.Messages(){
				//fmt.Printf("Partition:%d, Offset:%d, key:%s, value:%s\n", msg.Partition, msg.Offset, string(msg.Key), string(msg.Value))
				// 每次消费后都更新一次 offset,这里更新的只是程序内存中的值，需要 commit 之后才能提交到 kafka
				//加密
				//序列化对象
				var mess bean.Message
				err:=json.Unmarshal(msg.Value,&mess)
				if err != nil {
					log.Fatal("json unmarshal err: ", err)
				}
				data,_:=json.Marshal(mess.Data)
				dst:=encrypt.DesEncrypt(data,[]byte("12345678"))
				c<-dst
				partitionOffsetManager.MarkOffset(msg.Offset+1, "modified metadata") // MarkOffset 更新最后消费的 offset
			}
			defer partitionConsumer.AsyncClose()
		}(partitionConsumer)
	}
	//开xxx个协程用于加密上链
	wg.Add(1)
	go func() {
		defer wg.Done()
		for{
			x:=<-c
			//fmt.Println("解密后：%s", encrypt.DesDecrypt(x,[]byte("12345678")))
			//x=[]byte("")
			ethereum.Transfer_eth(x)
			//将x持久化到区块链上

		}
	}()
	// defer 在程序结束后在 commit 一次，防止自动提交间隔之间的信息被丢掉
	defer offsetManager.Commit()
	wg.Wait()
}
