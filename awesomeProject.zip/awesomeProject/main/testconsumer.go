package main

import "awesomeProject/main/consumer"

func main()  {
	consumer.PartitionsConsumer([]string{"123.56.14.174:9092","123.56.14.174:9093","123.56.14.174:9094"},"test3")
}
